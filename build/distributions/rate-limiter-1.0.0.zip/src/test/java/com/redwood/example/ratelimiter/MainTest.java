/*
 * (C) Copyright 2019-2025 Redwood Technology B.V., Houten, The Netherlands
 */

package com.redwood.example.ratelimiter;

import org.junit.jupiter.api.Test;

/**
 * A placeholder test class. Here so that the framework
 * build and test cycle passes correctly.
 */
public class MainTest {
    @Test
    public void testNothing() {
        // empty
    }
}
